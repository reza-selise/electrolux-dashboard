export const eluxTranslation = {
    eventDashboard: 'Event Dashboard',
    genericComments: 'Generic Comments',
    filters: 'Filters',
    startTyping: 'Start typing...',
    errorOccured: 'An error happened during api call',
    pleaseWait: 'Please wait...',
    timeline: 'Timeline',
};
