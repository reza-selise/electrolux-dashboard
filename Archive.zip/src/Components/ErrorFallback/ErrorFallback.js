import React from 'react';

function ErrorFallback() {
    return <div>An Error Occured Please Refresh The Page</div>;
}

export default ErrorFallback;
