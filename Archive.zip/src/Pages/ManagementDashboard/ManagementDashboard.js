import React from 'react';

function ManagementDashboard() {
    return <div>ManagementDashboard</div>;
}

export default ManagementDashboard;
