import React from 'react';

function CompactTable() {
    return <div>CompactTable</div>;
}

export default CompactTable;
