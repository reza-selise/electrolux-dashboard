import React from 'react';

function HomeConsultation() {
    return <div>HomeConsultation</div>;
}

export default HomeConsultation;
