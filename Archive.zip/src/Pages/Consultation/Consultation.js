import React from 'react';

function Consultation() {
    return <div>Consultation</div>;
}

export default Consultation;
